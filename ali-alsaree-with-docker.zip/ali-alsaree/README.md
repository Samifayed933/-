      # عليالسريع (AliAlsaree) - MVP

      ## تشغيل باستخدام Docker Compose (مُوصى به للمطورين)

      هذا الإعداد يشغّل Postgres، backend (Node.js) و frontend (React) عبر Docker.

      1. تأكد أن عندك Docker و Docker Compose منصبان.
      2. شغّل الأمر:

         ```bash
         docker compose up --build
         ```

      3. الواجهات ستكون متاحة عند:
         - Frontend: http://localhost:3000
         - Backend API: http://localhost:4000
         - Postgres: localhost:5432 (user: postgres, password: password)

      ## ملاحظات تشغيل محلي بدون Docker
      - Backend:
- املأ `backend/.env` بناءً على `backend/.env.example`.
- `cd backend && npm install && npm run dev`

      - Frontend:
- `cd frontend && npm install && npm run dev`

      ## محتويات المشروع
      - backend/: API باستخدام Express + TypeScript + Socket.IO
      - frontend/: واجهة React بسيطة
      - docker-compose.yml: لإطلاق Postgres + backend + frontend
