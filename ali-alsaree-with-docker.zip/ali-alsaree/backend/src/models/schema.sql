-- جدول المستخدمين (Customers + Drivers simple)
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT,
  phone TEXT UNIQUE,
  password_hash TEXT,
  role TEXT, -- 'customer' | 'driver' | 'vendor' | 'admin'
  created_at TIMESTAMP DEFAULT now()
);

-- جدول الطلبات
CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  customer_id INTEGER REFERENCES users(id),
  driver_id INTEGER REFERENCES users(id),
  pickup_address TEXT,
  dropoff_address TEXT,
  items JSONB,
  status TEXT DEFAULT 'pending', -- pending, assigned, picked, on_the_way, delivered, cancelled
  price NUMERIC DEFAULT 0,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- indexes
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
