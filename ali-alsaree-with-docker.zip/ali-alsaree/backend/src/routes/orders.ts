import { Router } from 'express';
import { query } from '../db';
import jwt from 'jsonwebtoken';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'secret';

// middleware بسيط للتحقق
function authMiddleware(req: any, res: any, next: any) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'no token' });
  const token = auth.split(' ')[1];
  try {
    const payload: any = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) { return res.status(401).json({ error: 'invalid token' }); }
}

// عمل طلب جديد
router.post('/', authMiddleware, async (req: any, res) => {
  const { pickup_address, dropoff_address, items, price } = req.body;
  const r = await query('INSERT INTO orders (customer_id, pickup_address, dropoff_address, items, price) VALUES ($1,$2,$3,$4,$5) RETURNING *',
    [req.user.id, pickup_address, dropoff_address, items || {}, price || 0]);
  const order = r.rows[0];
  // هنا يمكن اشعار السائقين عن طريق Socket
  res.json({ order });
});

// قائمة الطلبات المتاحة (للـdrivers)
router.get('/available', authMiddleware, async (req: any, res) => {
  const r = await query("SELECT * FROM orders WHERE status='pending'");
  res.json({ orders: r.rows });
});

// مسك طلب من سائق
router.post('/:id/assign', authMiddleware, async (req: any, res) => {
  const { id } = req.params;
  // فقط السائقين يسمح لهم
  if (req.user.role !== 'driver') return res.status(403).json({ error: 'forbidden' });
  const r = await query('UPDATE orders SET driver_id=$1, status=$2, updated_at=now() WHERE id=$3 RETURNING *',
    [req.user.id, 'assigned', id]);
  res.json({ order: r.rows[0] });
});

export default router;
