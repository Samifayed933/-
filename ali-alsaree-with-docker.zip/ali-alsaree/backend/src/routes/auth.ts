import { Router } from 'express';
import { query } from '../db';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'secret';

// تسجيل مستخدم (customer أو driver بناءًا على role)
router.post('/register', async (req, res) => {
  const { name, phone, password, role } = req.body;
  if (!phone || !password || !role) return res.status(400).json({ error: 'missing' });
  const hash = await bcrypt.hash(password, 10);
  try {
    const r = await query('INSERT INTO users (name, phone, password_hash, role) VALUES ($1,$2,$3,$4) RETURNING id, name, phone, role',
      [name, phone, hash, role]);
    const user = r.rows[0];
    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET);
    res.json({ user, token });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// تسجيل دخول
router.post('/login', async (req, res) => {
  const { phone, password } = req.body;
  const r = await query('SELECT id, name, phone, password_hash, role FROM users WHERE phone=$1', [phone]);
  if (r.rowCount === 0) return res.status(401).json({ error: 'invalid' });
  const user = r.rows[0];
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'invalid' });
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET);
  delete user.password_hash;
  res.json({ user, token });
});

export default router;
