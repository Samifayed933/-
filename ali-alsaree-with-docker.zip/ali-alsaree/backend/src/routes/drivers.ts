import { Router } from 'express';
import { query } from '../db';
const router = Router();

// endpoint بسيط لإحصائيات سائق
router.get('/:id/earnings', async (req, res) => {
  const { id } = req.params;
  // مثال: اجمالي السعر للطلبات المنجزة
  const r = await query("SELECT COALESCE(SUM(price),0) as total FROM orders WHERE driver_id=$1 AND status='delivered'", [id]);
  res.json({ total: r.rows[0].total });
});

export default router;
