import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import authRoutes from './routes/auth';
import ordersRoutes from './routes/orders';
import driversRoutes from './routes/drivers';

export const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use('/api/auth', authRoutes);
app.use('/api/orders', ordersRoutes);
app.use('/api/drivers', driversRoutes);

app.get('/', (req, res) => res.json({ ok: true, service: 'ali-alsaree backend' }));
