import { Server as HttpServer } from 'http';
import { Server, Socket } from 'socket.io';

let io: Server;
export function initSocket(server: HttpServer) {
  io = new Server(server, { cors: { origin: '*' } });
  io.on('connection', (socket: Socket) => {
    console.log('socket connected', socket.id);
    socket.on('join_driver', (driverId) => {
      socket.join(`driver_${driverId}`);
    });
    socket.on('disconnect', () => console.log('socket disconnect', socket.id));
  });
}

export function notifyDriver(driverId: number, event: string, payload: any) {
  if (!io) return;
  io.to(`driver_${driverId}`).emit(event, payload);
}
