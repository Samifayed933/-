import React, { useState } from 'react'
import API, { setToken } from '../services/api'

export default function CustomerHome(){
  const [pickup, setPickup] = useState('');
  const [dropoff, setDropoff] = useState('');
  const [items, setItems] = useState('');

  async function createOrder(){
    try{
      const r = await API.post('/orders', { pickup_address: pickup, dropoff_address: dropoff, items: [{ name: items }], price: 20 });
      alert('Order created: ' + r.data.order.id);
    }catch(e:any){ alert('error: '+ e.message) }
  }

  return (
    <div>
      <h2>انشاء طلب</h2>
      <div>
        <input placeholder="مكان الاستلام" value={pickup} onChange={e=>setPickup(e.target.value)} />
      </div>
      <div>
        <input placeholder="مكان التسليم" value={dropoff} onChange={e=>setDropoff(e.target.value)} />
      </div>
      <div>
        <input placeholder="وصف الطلب" value={items} onChange={e=>setItems(e.target.value)} />
      </div>
      <button onClick={createOrder}>اطلب</button>
    </div>
  )
}
