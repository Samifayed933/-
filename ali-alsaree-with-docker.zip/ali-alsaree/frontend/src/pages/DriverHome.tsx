import React, { useEffect, useState } from 'react'
import API from '../services/api'
import { io } from 'socket.io-client'

export default function DriverHome(){
  const [orders, setOrders] = useState<any[]>([]);

  useEffect(()=>{
    fetchAvailable();
    const socket = io(import.meta.env.VITE_API_URL?.replace('/api','') || 'http://localhost:4000');
    // هنا لو عندنا تعريف للسائق نعمل join
    // socket.emit('join_driver', driverId)
    return ()=>{ socket.disconnect(); }
  },[])

  async function fetchAvailable(){
    const r = await API.get('/orders/available');
    setOrders(r.data.orders || []);
  }

  async function assign(id:number){
    await API.post(`/orders/${id}/assign`);
    alert('assigned')
    fetchAvailable();
  }

  return (
    <div>
      <h2>طلبات متاحة</h2>
      {orders.map(o=> (
        <div key={o.id} style={{border:'1px solid #ddd', padding:8, margin:8}}>
          <div>#{o.id} {o.pickup_address} → {o.dropoff_address}</div>
          <div>سعر: {o.price}</div>
          <button onClick={()=>assign(o.id)}>استلام</button>
        </div>
      ))}
    </div>
  )
}
