import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import CustomerHome from './pages/CustomerHome'
import DriverHome from './pages/DriverHome'

export default function App(){
  return (
    <div className="app">
      <header style={{padding:12, borderBottom:'1px solid #eee'}}>
        <Link to="/">عليالسريع</Link> | <Link to="/driver">سائق</Link>
      </header>
      <main style={{padding:12}}>
        <Routes>
          <Route path="/" element={<CustomerHome/>} />
          <Route path="/driver" element={<DriverHome/>} />
        </Routes>
      </main>
    </div>
  )
}
